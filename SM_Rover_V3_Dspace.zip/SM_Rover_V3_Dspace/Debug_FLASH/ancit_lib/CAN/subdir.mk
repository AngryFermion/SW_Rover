################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/CAN/ancit_can.c \
../ancit_lib/CAN/ancit_can_rx.c \
../ancit_lib/CAN/ancit_can_tx.c 

OBJS += \
./ancit_lib/CAN/ancit_can.o \
./ancit_lib/CAN/ancit_can_rx.o \
./ancit_lib/CAN/ancit_can_tx.o 

C_DEPS += \
./ancit_lib/CAN/ancit_can.d \
./ancit_lib/CAN/ancit_can_rx.d \
./ancit_lib/CAN/ancit_can_tx.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/CAN/%.o: ../ancit_lib/CAN/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/CAN/ancit_can.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


