################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/i2c/i2c_manager/ancit_i2c_manager.c 

OBJS += \
./ancit_lib/i2c/i2c_manager/ancit_i2c_manager.o 

C_DEPS += \
./ancit_lib/i2c/i2c_manager/ancit_i2c_manager.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/i2c/i2c_manager/%.o: ../ancit_lib/i2c/i2c_manager/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/i2c/i2c_manager/ancit_i2c_manager.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


