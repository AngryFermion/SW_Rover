################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/i2c/oled/ancit_oled_driver.c \
../ancit_lib/i2c/oled/ancit_oled_handler.c \
../ancit_lib/i2c/oled/ssd1306_fonts.c 

OBJS += \
./ancit_lib/i2c/oled/ancit_oled_driver.o \
./ancit_lib/i2c/oled/ancit_oled_handler.o \
./ancit_lib/i2c/oled/ssd1306_fonts.o 

C_DEPS += \
./ancit_lib/i2c/oled/ancit_oled_driver.d \
./ancit_lib/i2c/oled/ancit_oled_handler.d \
./ancit_lib/i2c/oled/ssd1306_fonts.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/i2c/oled/%.o: ../ancit_lib/i2c/oled/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/i2c/oled/ancit_oled_driver.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


