################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/Timers/ancit_scheduler.c \
../ancit_lib/Timers/ancit_timer.c 

OBJS += \
./ancit_lib/Timers/ancit_scheduler.o \
./ancit_lib/Timers/ancit_timer.o 

C_DEPS += \
./ancit_lib/Timers/ancit_scheduler.d \
./ancit_lib/Timers/ancit_timer.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/Timers/%.o: ../ancit_lib/Timers/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/Timers/ancit_scheduler.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


