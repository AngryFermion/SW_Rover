################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/Ultrasonic/ancit_ultrasonic.c 

OBJS += \
./ancit_lib/Ultrasonic/ancit_ultrasonic.o 

C_DEPS += \
./ancit_lib/Ultrasonic/ancit_ultrasonic.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/Ultrasonic/%.o: ../ancit_lib/Ultrasonic/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/Ultrasonic/ancit_ultrasonic.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


