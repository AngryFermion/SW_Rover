################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/Digital/ancit_do.c \
../ancit_lib/Digital/ancit_pwm.c 

OBJS += \
./ancit_lib/Digital/ancit_do.o \
./ancit_lib/Digital/ancit_pwm.o 

C_DEPS += \
./ancit_lib/Digital/ancit_do.d \
./ancit_lib/Digital/ancit_pwm.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/Digital/%.o: ../ancit_lib/Digital/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/Digital/ancit_do.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


