################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_lib/Others/ancit_common.c 

OBJS += \
./ancit_lib/Others/ancit_common.o 

C_DEPS += \
./ancit_lib/Others/ancit_common.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_lib/Others/%.o: ../ancit_lib/Others/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_lib/Others/ancit_common.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


