ancit_lib/Others/ancit_common.o: ../ancit_lib/Others/ancit_common.c \
 ../ancit_lib/Others/ancit_common.h

../ancit_lib/Others/ancit_common.h:
