################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
LD_SRCS := 
TODISASSEMBLE_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_UPPER_SRCS := 
TOPREPROCESS_SRCS := 
ASM_SRCS := 
C_SRCS := 
O_SRCS := 
S_UPPER_SRCS := 
EXECUTABLES := 
OBJS := 
SECONDARY_SIZE := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Project_Settings/Linker_Files \
Project_Settings/Startup_Code \
SDK/platform/devices/S32K144/startup \
SDK/platform/devices \
SDK/platform/drivers/src/adc \
SDK/platform/drivers/src/clock/S32K1xx \
SDK/platform/drivers/src/edma \
SDK/platform/drivers/src/flash \
SDK/platform/drivers/src/flexcan \
SDK/platform/drivers/src/ftm \
SDK/platform/drivers/src/interrupt \
SDK/platform/drivers/src/lpi2c \
SDK/platform/drivers/src/lptmr \
SDK/platform/drivers/src/lpuart \
SDK/platform/drivers/src/pins \
SDK/rtos/osif \
ancit_device_drivers \
ancit_lib/CAN \
ancit_lib/Digital \
ancit_lib/Others \
ancit_lib/Timers \
ancit_lib/Ultrasonic \
ancit_lib/i2c/i2c_manager \
ancit_lib/i2c/oled \
board \
src \

