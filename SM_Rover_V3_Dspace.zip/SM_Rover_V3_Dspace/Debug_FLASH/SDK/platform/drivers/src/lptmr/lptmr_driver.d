SDK/platform/drivers/src/lptmr/lptmr_driver.o: \
 ../SDK/platform/drivers/src/lptmr/lptmr_driver.c \
 ../SDK/platform/drivers/inc/lptmr_driver.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/status.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h \
 ../SDK/platform/drivers/src/lptmr/lptmr_hw_access.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock_manager.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock.h \
 d:\nxp\s32ds\software\s32sdk_s32k1xx_rtm_4.0.1\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/platform/drivers/inc/lptmr_driver.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/status.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h:

../SDK/platform/drivers/src/lptmr/lptmr_hw_access.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock_manager.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/clock.h:

d:\nxp\s32ds\software\s32sdk_s32k1xx_rtm_4.0.1\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
