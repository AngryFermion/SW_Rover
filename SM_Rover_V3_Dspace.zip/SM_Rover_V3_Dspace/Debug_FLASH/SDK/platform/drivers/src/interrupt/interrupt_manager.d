SDK/platform/drivers/src/interrupt/interrupt_manager.o: \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/src/interrupt/interrupt_manager.c \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/interrupt_manager.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/startup.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/interrupt_manager.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/startup.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h:
