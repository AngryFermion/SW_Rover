SDK/platform/drivers/src/flash/flash_driver.o: \
 ../SDK/platform/drivers/src/flash/flash_driver.c \
 ../SDK/platform/drivers/inc/flash_driver.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/status.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/inc/flash_driver.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/status.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/drivers/inc/interrupt_manager.h:
