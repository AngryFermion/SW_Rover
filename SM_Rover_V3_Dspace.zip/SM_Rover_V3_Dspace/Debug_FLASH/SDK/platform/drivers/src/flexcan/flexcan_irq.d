SDK/platform/drivers/src/flexcan/flexcan_irq.o: \
 ../SDK/platform/drivers/src/flexcan/flexcan_irq.c \
 ../SDK/platform/drivers/src/flexcan/flexcan_irq.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h

../SDK/platform/drivers/src/flexcan/flexcan_irq.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h:
