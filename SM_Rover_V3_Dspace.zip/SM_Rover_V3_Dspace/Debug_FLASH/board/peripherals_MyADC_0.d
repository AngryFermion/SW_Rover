board/peripherals_MyADC_0.o: ../board/peripherals_MyADC_0.c \
 ../board/peripherals_MyADC_0.h ../SDK/platform/drivers/inc/adc_driver.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h

../board/peripherals_MyADC_0.h:

../SDK/platform/drivers/inc/adc_driver.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/device_registers.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/common/s32_core_cm4.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/S32K144/include/S32K144_features.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/devassert.h:
