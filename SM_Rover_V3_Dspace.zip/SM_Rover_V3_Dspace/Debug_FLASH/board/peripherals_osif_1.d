board/peripherals_osif_1.o: ../board/peripherals_osif_1.c \
 ../board/peripherals_osif_1.h ../SDK/rtos/osif/osif.h \
 D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/status.h

../board/peripherals_osif_1.h:

../SDK/rtos/osif/osif.h:

D:/NXP/S32DS/software/S32SDK_S32K1XX_RTM_4.0.1/platform/devices/status.h:
