################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ancit_device_drivers/ancit_driver_can.c \
../ancit_device_drivers/ancit_driver_digital_io.c \
../ancit_device_drivers/ancit_driver_timer.c 

OBJS += \
./ancit_device_drivers/ancit_driver_can.o \
./ancit_device_drivers/ancit_driver_digital_io.o \
./ancit_device_drivers/ancit_driver_timer.o 

C_DEPS += \
./ancit_device_drivers/ancit_driver_can.d \
./ancit_device_drivers/ancit_driver_digital_io.d \
./ancit_device_drivers/ancit_driver_timer.d 


# Each subdirectory must supply rules for building sources it contributes
ancit_device_drivers/%.o: ../ancit_device_drivers/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@ancit_device_drivers/ancit_driver_can.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


