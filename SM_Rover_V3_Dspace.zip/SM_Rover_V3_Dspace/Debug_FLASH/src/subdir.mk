################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/ACC.c \
../src/ACC_data.c \
../src/SK_DC.c \
../src/genx_can_rx.c \
../src/genx_can_tx.c \
../src/genx_common.c \
../src/genx_do.c \
../src/genx_i2c_manager.c \
../src/genx_oled.c \
../src/genx_pwm.c \
../src/genx_scheduler.c \
../src/genx_simulink_bridge.c \
../src/main.c \
../src/rt_logging.c \
../src/rt_nonfinite.c \
../src/smartwheels_rover.c 

OBJS += \
./src/ACC.o \
./src/ACC_data.o \
./src/SK_DC.o \
./src/genx_can_rx.o \
./src/genx_can_tx.o \
./src/genx_common.o \
./src/genx_do.o \
./src/genx_i2c_manager.o \
./src/genx_oled.o \
./src/genx_pwm.o \
./src/genx_scheduler.o \
./src/genx_simulink_bridge.o \
./src/main.o \
./src/rt_logging.o \
./src/rt_nonfinite.o \
./src/smartwheels_rover.o 

C_DEPS += \
./src/ACC.d \
./src/ACC_data.d \
./src/SK_DC.d \
./src/genx_can_rx.d \
./src/genx_can_tx.d \
./src/genx_common.d \
./src/genx_do.d \
./src/genx_i2c_manager.d \
./src/genx_oled.d \
./src/genx_pwm.d \
./src/genx_scheduler.d \
./src/genx_simulink_bridge.d \
./src/main.d \
./src/rt_logging.d \
./src/rt_nonfinite.d \
./src/smartwheels_rover.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/ACC.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


