src/smartwheels_rover.o: ../src/smartwheels_rover.c \
 ../src/smartwheels_rover.h

../src/smartwheels_rover.h:
